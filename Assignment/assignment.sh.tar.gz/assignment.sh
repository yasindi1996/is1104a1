#!/bin/bash

mv .Resources/ Resources/
sudo chmod u-x Resources/
sudo chmod u-r Resources/
sudo chmod u-w Resources/index.html
echo "Assignment is Ready Now"
